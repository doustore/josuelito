# Cambios de la pantalla de acceso

- Se retiró la interfaz y la marca visual de Spotify, así como el video de fondo asociado a esa pantalla.
- La aplicación inicia ahora con una brújula negra e interactiva que se puede girar con el dedo.
- La lectura de la brújula comienza en 315° y muestra una flecha roja que acompaña el giro.
- Al llegar a 210° (margen de 2°), se abre la pantalla para ingresar la key.
- Al continuar desde la pantalla de key, se abre la vista principal anterior de DOUR.
- La ubicación que aparece debajo de la brújula está fijada visualmente en Washington, Estados Unidos, con coordenadas y altitud de referencia. No modifica la ubicación GPS real del dispositivo.
