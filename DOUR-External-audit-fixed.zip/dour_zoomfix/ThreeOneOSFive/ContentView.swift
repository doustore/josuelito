import SwiftUI
import UIKit
import AVFoundation

struct ContentView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchDraftCoordinator: PatchDraftCoordinator
    @State private var tabNavigation: AppTabNavigationState
    @State private var launchStage = 0 // 0 = splash, 1 = bienvenida, 2 = login, 3 = key, 4 = aplicación
    @State private var accessText = ""
    @State private var loginEmail = ""
    @State private var showingOriginalApp = false
    @AppStorage(FeatureVisibility.cleanerStorageKey) private var cleanerEnabled = true
    @AppStorage(FeatureVisibility.wallpapersStorageKey) private var wallpapersEnabled = true

    init() {
#if targetEnvironment(simulator)
        let arguments = ProcessInfo.processInfo.arguments
        let initialTab: Int
        if arguments.contains("--simulate-files-tab") {
            initialTab = 1
        } else if arguments.contains("--simulate-patch-tab") {
            initialTab = 2
        } else if arguments.contains("--simulate-cleaner-tab") {
            initialTab = 3
        } else if arguments.contains("--simulate-wallpaper-tab") {
            initialTab = 4
        } else {
            initialTab = AppSection.patches.rawValue
        }
        _tabNavigation = State(initialValue: AppTabNavigationState(selectedTab: initialTab))
#else
        _tabNavigation = State(initialValue: AppTabNavigationState())
#endif
    }

    var body: some View {
        Group {
            switch launchStage {
            case 0:
                DOURSplashScreen {
                    withAnimation(.easeInOut(duration: 0.35)) { launchStage = 1 }
                }
            case 1:
                DOURWelcomeScreen {
                    withAnimation(.easeInOut(duration: 0.25)) { launchStage = 2 }
                }
            case 2:
                DOURLoginScreen(email: $loginEmail) {
                    withAnimation(.easeInOut(duration: 0.25)) { launchStage = 3 }
                }
            case 3:
                DOURKeyEntryView(accessText: $accessText) {
                    withAnimation(.easeInOut(duration: 0.25)) { launchStage = 4 }
                }
            default:
                PatchProjectsView(ghostTheme: true)
            }
        }
        .background(Color.black.ignoresSafeArea())
        .statusBarHidden(true)
        .tint(AppTheme.accent)
        .imageScale(.small)
        .onChange(of: patchDraftCoordinator.request?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: patchDraftCoordinator.importRequest?.id) { requestID in
            if requestID != nil { tabNavigation.select(AppSection.patches.rawValue) }
        }
        .onChange(of: cleanerEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onChange(of: wallpapersEnabled) { _ in
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
        .onAppear {
            tabNavigation.reconcileSelection(with: featureVisibility)
        }
    }

    private var compactLayout: some View {
        TabView(selection: tabSelection) {
            ForEach(featureVisibility.visibleSections) { section in
                sectionContent(section)
                    .background(Color.black.ignoresSafeArea())
                    .tabItem {
                        CompactTabLabel(
                            title: language.text(section.titleKey),
                            systemImage: section.systemImage
                        )
                    }
                    .tag(section.rawValue)
            }
        }
        .background(Color.black.ignoresSafeArea())
        .toolbarBackground(Color.black, for: .tabBar)
        .toolbarBackground(.visible, for: .tabBar)
        .toolbarColorScheme(.dark, for: .tabBar)
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List {
                ForEach(featureVisibility.visibleSections) { section in
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            tabNavigation.select(section.rawValue)
                        }
                    } label: {
                        Label(language.text(section.titleKey), systemImage: section.systemImage)
                            .fontWeight(section.rawValue == tabNavigation.selectedTab ? .semibold : .regular)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .listRowBackground(
                        section.rawValue == tabNavigation.selectedTab
                            ? AppTheme.accent.opacity(0.14)
                            : Color.clear
                    )
                    .accessibilityAddTraits(
                        section.rawValue == tabNavigation.selectedTab ? .isSelected : []
                    )
                }
            }
            .navigationTitle("3105")
            .navigationSplitViewColumnWidth(min: 210, ideal: 240, max: 300)
        } detail: {
            sectionContent(selectedVisibleSection)
                .id(selectedVisibleSection.rawValue)
        }
        .navigationSplitViewStyle(.balanced)
    }

    @ViewBuilder
    private func sectionContent(_ section: AppSection) -> some View {
        switch section {
        case .home:
            DashboardView(
                cleanerEnabled: $cleanerEnabled,
                wallpapersEnabled: $wallpapersEnabled,
                wallpapersSupported: wallpapersSupported
            )
        case .files:
            AppDataBrowserView(
                tabSession: filesTabSession
            )
        case .patches:
            PatchProjectsView(ghostTheme: true)
        case .cleaner:
            CleanerView()
        case .wallpapers:
            WallpaperLabView()
        }
    }

    private var tabSelection: Binding<Int> {
        Binding(
            get: { tabNavigation.selectedTab },
            set: { tabNavigation.select($0) }
        )
    }

    private var filesTabSession: Binding<FilesTabSession> {
        Binding(
            get: { tabNavigation.filesTabs },
            set: { tabNavigation.setFilesTabs($0) }
        )
    }

    private var featureVisibility: FeatureVisibility {
        FeatureVisibility(
            cleanerEnabled: cleanerEnabled,
            wallpapersEnabled: wallpapersEnabled,
            wallpapersSupported: wallpapersSupported
        )
    }

    private var wallpapersSupported: Bool {
        WallpaperFeatureSupportPolicy.isSupported(major: AppInfo.versionTuple.major)
    }

    private var selectedVisibleSection: AppSection {
        guard let section = AppSection(rawValue: tabNavigation.selectedTab),
              featureVisibility.isVisible(section) else {
            return .patches
        }
        return section
    }
}


private struct DOURSplashScreen: View {
    let onFinished: () -> Void

    var body: some View {
        Image("DOURSplash")
            .resizable()
            .scaledToFill()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.black)
            .clipped()
            .ignoresSafeArea()
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    onFinished()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .ignoresSafeArea(.all)
    }
}

private struct DOURWelcomeScreen: View {
    let onLogin: () -> Void

    var body: some View {
        ReferenceImageScreen(imageName: "DOURWelcome") {
            // The visible "Log in" button in the reference screen.
            onLogin()
        }
    }
}

private struct DOURLoginScreen: View {
    @Binding var email: String
    let onContinue: () -> Void

    var body: some View {
        GeometryReader { geometry in
            // Keep the complete login artwork visible. On taller iPhones the
            // original asset is narrower than the screen, so a soft blurred
            // extension fills the remaining space without cropping the design.
            let artworkAspectRatio: CGFloat = 1179.0 / 2124.0
            let artworkHeight = min(geometry.size.height, geometry.size.width / artworkAspectRatio)
            let artworkTop = (geometry.size.height - artworkHeight) / 2

            ZStack {
                Image("DOURLogin")
                    .resizable()
                    .scaledToFill()
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .blur(radius: 26)
                    .overlay(Color.black.opacity(0.34))
                    .clipped()

                Image("DOURLogin")
                    .resizable()
                    .scaledToFit()
                    .frame(width: geometry.size.width, height: geometry.size.height)

                // Editable email field and Continue hit target stay aligned
                // with the original artwork after removing the unwanted zoom.
                TextField("", text: $email)
                    .textContentType(.emailAddress)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .foregroundStyle(.white)
                    .tint(.white)
                    .padding(.horizontal, 16)
                    .frame(width: geometry.size.width * 0.80,
                           height: artworkHeight * 0.065)
                    .background(Color.clear)
                    .position(x: geometry.size.width * 0.50,
                              y: artworkTop + artworkHeight * 0.695)

                Button(action: onContinue) {
                    Color.clear
                        .frame(width: geometry.size.width * 0.86,
                               height: artworkHeight * 0.105)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Continue to key entry")
                .position(x: geometry.size.width * 0.50,
                          y: artworkTop + artworkHeight * 0.775)
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .background(Color.black)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .ignoresSafeArea(.all)
        .background(Color.black)
        .preferredColorScheme(.dark)
    }
}

private struct ReferenceImageScreen: View {
    let imageName: String
    let onPrimaryAction: () -> Void

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Image(imageName)
                    .resizable()
                    .scaledToFill()
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .clipped()

                Button(action: onPrimaryAction) {
                    Color.clear
                        .frame(width: geometry.size.width * 0.86,
                               height: geometry.size.height * 0.11)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Log in")
                .position(x: geometry.size.width * 0.50,
                          y: geometry.size.height * 0.835)
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .background(Color.black)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .ignoresSafeArea(.all)
        .background(Color.black)
        .preferredColorScheme(.dark)
    }
}

private struct CompactTabLabel: View {
    let title: String
    let systemImage: String

    @ViewBuilder
    var body: some View {
        if let image = UIImage(
            systemName: systemImage,
            withConfiguration: UIImage.SymbolConfiguration(pointSize: 17, weight: .medium)
        )?.withRenderingMode(.alwaysTemplate) {
            Image(uiImage: image)
        } else {
            Image(systemName: systemImage)
                .font(.system(size: 17, weight: .medium))
        }
        Text(title)
    }
}

private extension AppSection {
    var titleKey: String {
        switch self {
        case .home: return "tab.home"
        case .files: return "tab.files"
        case .patches: return "tab.patches"
        case .cleaner: return "tab.cleaner"
        case .wallpapers: return "tab.wallpapers"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .files: return "folder.fill"
        case .patches: return "shippingbox.fill"
        case .cleaner: return "sparkles"
        case .wallpapers: return "photo.on.rectangle.angled"
        }
    }
}

private struct DashboardView: View {
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @State private var showSettings = false
    @State private var showLogs = false
    @Binding var cleanerEnabled: Bool
    @Binding var wallpapersEnabled: Bool
    let wallpapersSupported: Bool

    var body: some View {
        NavigationStack {
            List {
                deviceSection
                featuresSection
            }
            .navigationBarTitleDisplayMode(.inline)
            .tint(AppTheme.accent)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showLogs = true } label: {
                        Image(systemName: "apple.terminal")
                    }
                    .accessibilityLabel(language.text("accessibility.open_logs"))
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Link(destination: URL(string: "https://t.me/+6L89Qcso3w9kN2Yx")!) {
                        Image(systemName: "paperplane.fill")
                            .foregroundStyle(.cyan)
                    }
                    .accessibilityLabel("Abrir grupo de Telegram")
                }
            }
            .sheet(isPresented: $showSettings) { SettingsView() }
            .sheet(isPresented: $showLogs) { LogView() }
        }
    }

    private var featuresSection: some View {
        Section {
            Toggle(isOn: $cleanerEnabled) {
                Label(language.text("tab.cleaner"), systemImage: "sparkles")
            }
            if wallpapersSupported {
                Toggle(isOn: $wallpapersEnabled) {
                    Label(language.text("tab.wallpapers"), systemImage: "photo.on.rectangle.angled")
                }
            }
        } header: {
            Text(language.text("dashboard.features"))
        } footer: {
            Text(language.text("dashboard.features_footer"))
        }
    }

    private var deviceSection: some View {
        Section {
            LabeledContent(language.text("dashboard.hardware_model")) {
                Text(AppInfo.displayMachineName)
                    .font(.body.monospaced())
            }
            LabeledContent(language.text("settings.ios_version")) {
                Text("\(AppInfo.osVersion) (\(AppInfo.osBuild))")
                    .font(.body.monospaced())
            }
            HStack {
                Text(language.text("settings.compatibility"))
                Spacer()
                Text(language.text(appState.isSupported ? "settings.supported" : "settings.unsupported"))
                .foregroundStyle(appState.isSupported ? Color.green : Color.red)
            }

            if appState.kernelExploitApplicable && AppInfo.versionTuple.major < 26 {
                HStack {
                    Text(language.text("dashboard.kernel_status"))
                    Spacer()
                    if appState.kernelExploitRunning {
                        HStack(spacing: 6) {
                            ProgressView().controlSize(.small)
                            Text(language.text("dashboard.kernel_running"))
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    } else {
                        Text(language.text(appState.exploitStatus.isSuccess ? "dashboard.kernel_active" : "dashboard.kernel_inactive"))
                        .foregroundStyle(appState.exploitStatus.isSuccess ? Color.green : Color.secondary)
                    }
                }
            }
        } header: {
            Text(language.text("common.device"))
        } footer: {
            Text(language.text("settings.supported_range_summary"))
        }
    }
}


// MARK: - DOUR key entry

private struct DOURKeyEntryView: View {
    @Binding var accessText: String
    let onContinue: () -> Void
    @StateObject private var backgroundPlayer = DOURKeyBackgroundPlayer()

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                DOURKeyVideoLayer(player: backgroundPlayer.player)
                    .ignoresSafeArea()
                LinearGradient(
                    colors: [.black.opacity(0.60), .black.opacity(0.28), .black.opacity(0.72)],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()

                VStack(spacing: 20) {
                    Spacer()
                    Text("DOUR External")
                        .font(.system(size: 36, weight: .black, design: .rounded))
                        .tracking(1.5)
                        .foregroundStyle(.white)
                        .shadow(color: .black.opacity(0.55), radius: 12)

                    Text("ACCESO EXTERNO")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .tracking(3)
                        .foregroundStyle(.white.opacity(0.78))

                    TextField("Ingrese su key", text: $accessText)
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.white)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .padding(.horizontal, 22)
                        .frame(height: 64)
                        .background(.black.opacity(0.38))
                        .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.34), lineWidth: 1))
                        .clipShape(RoundedRectangle(cornerRadius: 18))

                    Button(action: onContinue) {
                        Text("CONTINUAR")
                            .font(.system(size: 18, weight: .black, design: .rounded))
                            .tracking(2)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 62)
                            .background(Color(red: 0.10, green: 0.72, blue: 0.34), in: RoundedRectangle(cornerRadius: 20))
                    }
                    .buttonStyle(.plain)

                    Link(destination: URL(string: "https://t.me/Jxsuesinho")!) {
                        HStack(spacing: 9) {
                            Image(systemName: "paperplane.fill")
                            Text("Contacto")
                        }
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 24)
                        .frame(height: 46)
                        .background(.white.opacity(0.16), in: Capsule())
                        .overlay(Capsule().stroke(.white.opacity(0.42), lineWidth: 1))
                    }
                    .buttonStyle(.plain)

                    Spacer()
                }
                .padding(.horizontal, 30)
                .frame(maxWidth: 520)
                .frame(height: geometry.size.height)
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
            .background(Color.black.ignoresSafeArea())
        }
        .ignoresSafeArea()
        .preferredColorScheme(.dark)
        .onAppear { backgroundPlayer.play() }
        .onDisappear { backgroundPlayer.pause() }
    }
}

private final class DOURKeyBackgroundPlayer: ObservableObject {
    let player: AVQueuePlayer
    private var looper: AVPlayerLooper?

    init() {
        if let url = Bundle.main.url(forResource: "DOURKeyBackground", withExtension: "mp4") {
            let item = AVPlayerItem(url: url)
            let queue = AVQueuePlayer()
            player = queue
            looper = AVPlayerLooper(player: queue, templateItem: item)
            player.isMuted = true
            player.actionAtItemEnd = .none
        } else {
            player = AVQueuePlayer()
        }
    }

    func play() { player.play() }
    func pause() { player.pause() }
}

private struct DOURKeyVideoLayer: UIViewRepresentable {
    let player: AVPlayer

    func makeUIView(context: Context) -> PlayerContainerView {
        let view = PlayerContainerView()
        view.playerLayer.player = player
        view.playerLayer.videoGravity = .resizeAspectFill
        return view
    }

    func updateUIView(_ uiView: PlayerContainerView, context: Context) {
        uiView.playerLayer.player = player
    }
}

private final class PlayerContainerView: UIView {
    override class var layerClass: AnyClass { AVPlayerLayer.self }
    var playerLayer: AVPlayerLayer { layer as! AVPlayerLayer }
}
